package com.LoginPage;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.HomePage.HomePage;
import com.PageChecker.LoginPageChecker;
import com.SignUpPage.SignupPage;
import com.appdirect.nitya.utils.WaitClass;

import junit.framework.Assert;

public class LoginPage {
	
	WebDriver driver;
	String signupPath;
	WaitClass wc=new WaitClass(driver);
	public LoginPage(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		this.driver=driver;
		Properties prop = new Properties();
		try
		{
		InputStream input = new FileInputStream(new File("Pages/com/LoginPage/Login.properties"));
		prop.load(input);
		}
		catch(Exception e)
		{
			throw new MyFileNotFoundException("detail of login not found");
		}
	    signupPath=prop.getProperty("signupPath");
	    if(signupPath==null){
		Reporter.log("signupPath:signup element not found",true);
		throw new MyNoSuchElementException("signupPath:signup element not found");
	}
	}
	public LoginPageChecker loginPageCheckerObject(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		wc.waitVisibilityConditionByXpath(signupPath,driver);
		return new LoginPageChecker(driver);
	}
	public WebDriver clicksignup(WebDriver driver){
		driver.findElement(By.xpath(signupPath)).click();
		Reporter.log("Signup Button Clicked",true);
		return driver;
	}

	

}
