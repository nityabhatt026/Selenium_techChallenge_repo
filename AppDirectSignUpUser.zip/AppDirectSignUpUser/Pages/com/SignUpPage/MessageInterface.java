package com.SignUpPage;

import org.openqa.selenium.WebDriver;

import com.ExceptionHandling.MyIOException;

public interface MessageInterface {
	public Message waitVisibilityConditionByXpath(WebDriver driver) throws MyIOException;
	public WebDriver WarningMessage(WebDriver driver);
}
