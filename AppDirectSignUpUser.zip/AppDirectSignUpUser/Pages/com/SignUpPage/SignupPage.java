package com.SignUpPage;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.LoginPage.LoginPage;
import com.PageChecker.SignupPageChecker;
import com.appdirect.nitya.utils.WaitClass;

import junit.framework.Assert;

public class SignupPage {
	WebDriver driver;
	String signupTextboxPath;
	String signupButton;
	WaitClass wc=new WaitClass(driver);
	public SignupPage(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		this.driver=driver;
		Properties prop = new Properties();
		try{
		File file=new File("Pages/com/SignUpPage/SignUp.properties");
		InputStream input = new FileInputStream(file);
		prop.load(input);
		}
		catch(Exception e)
		{
			throw new MyFileNotFoundException("file of signup detail not found");
		}
		signupTextboxPath=prop.getProperty("signupTextboxPath");
		signupButton=prop.getProperty("signupButton");
		if(signupTextboxPath==null && signupButton==null){
			Reporter.log("signupTextboxPath or signupButton : No such element Exception");
			throw new MyNoSuchElementException("signupTextboxPath or signupButton : No such element Exceptio");
		}
	}
	
	public SignupPageChecker signupPageCheckerObject(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		wc.waitVisibilityConditionByCss(signupTextboxPath, driver);
		return new SignupPageChecker(driver);
	}
	public SignupPageChecker signupID(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		String signupId = (RandomStringUtils.randomAlphabetic(5, 10)+"."+RandomStringUtils.randomAlphabetic(5,10)+"@yopmail.com").toLowerCase();
		//String signupId="nitya.bhatt@appdirect.com";
		Reporter.log(signupId,true);
		driver.findElement(By.cssSelector(signupTextboxPath)).sendKeys(signupId);
		return new SignupPageChecker(driver);
	}
   
   
   public WebDriver submitSignupId(WebDriver driver){
	   
	   Reporter.log("Clicked on Signup",true);
	   driver.findElement(By.cssSelector(signupButton)).click(); 
	   return driver;
   }
   
   
}
