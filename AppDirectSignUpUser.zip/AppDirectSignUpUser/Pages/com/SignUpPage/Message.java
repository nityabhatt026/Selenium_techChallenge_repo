package com.SignUpPage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyIOException;

import junit.framework.Assert;

public class Message {

	WebDriver driver;
	WebDriverWait wait;
	Properties prop = new Properties();
	String errorMessage;
	String successMessage;
	public Message(WebDriver driver) throws MyFileNotFoundException{
		this.driver=driver;
		try
		{
		InputStream input = new FileInputStream(new File("Pages/com/SignUpPage/SignUp.properties"));
		prop.load(input);
		}
		catch(Exception e)
		{
			throw new MyFileNotFoundException("signup file not found");
		}
		//errorMessage=prop.getProperty("errorMessage");
		//successMessage=prop.getProperty("successMessage");
		
	}
	
	public Message waitVisibilityConditionByXpath(WebDriver driver) throws MyIOException{
		try{
        wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".signupConfirmationPanel")));      
        return new Message(driver);
		}
		catch(Exception e){
			Reporter.log("Already existed email Id");
			throw new MyIOException("Already existed email Id");
		}
   }

	public WebDriver WarningMessage(WebDriver driver){
		if(driver.findElement(By.cssSelector(".signupConfirmationPanel")).isDisplayed()){
        Reporter.log("Success Message Displayed.... Thanks for registering.We have sent a verification email to your signup email id."
        		+ "Please check your inbox and click the link to activate your account.",true);
        Assert.assertTrue(true);
	}
		return driver;
   }
  	
}
