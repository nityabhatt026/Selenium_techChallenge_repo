package com.HomePage;

import org.testng.Assert;
import org.testng.AssertJUnit;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import javax.xml.xpath.XPath;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.LoginPage.LoginPage;
import com.PageChecker.HomePageChecker;
import com.appdirect.nitya.utils.WaitClass;

public class HomePage {
	WebDriver driver;
	WaitClass wc=new WaitClass(driver);
	Properties prop= new Properties();
	String loginXpath;
	public HomePage(WebDriver driver) throws MyNoSuchElementException{
		this.driver=driver;
		try
		{
		InputStream input = new FileInputStream(new File("Pages/com/HomePage/home.properties"));
		prop.load(input);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		loginXpath=(prop.getProperty("loginPath"));
		if(loginXpath==null){
			Reporter.log("login element not found",true);
			throw new MyNoSuchElementException("login element not found in exception handling");
		}
	}
	public HomePageChecker homePageCheckerObject(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		wc.waitVisibilityConditionByXpath(loginXpath,driver);
		return new HomePageChecker(driver);
	}
	public WebDriver clickLogin(WebDriver driver) {
	
		driver.findElement(By.xpath(loginXpath)).click();
		Reporter.log("login button clicked",true);
		return driver;
	}   
}
