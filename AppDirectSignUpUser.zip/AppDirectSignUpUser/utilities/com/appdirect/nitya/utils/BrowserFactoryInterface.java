package com.appdirect.nitya.utils;

import org.openqa.selenium.WebDriver;

public interface BrowserFactoryInterface {
	public WebDriver startBrowser();
	
}
