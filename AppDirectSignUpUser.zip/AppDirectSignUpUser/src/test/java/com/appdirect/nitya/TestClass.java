package com.appdirect.nitya;

import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.appdirect.nitya.utils.WaitClass;
import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyIOException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.ExceptionHandling.MyNullPointerException;
import com.HomePage.HomePage;
import com.LoginPage.LoginPage;
import com.PageChecker.BrowserChecker;
import com.PageChecker.HomePageChecker;
import com.SignUpPage.Message;
import com.SignUpPage.SignupPage;
import com.appdirect.nitya.utils.BrowserFactory;


public class TestClass implements TestClassInterface {
WaitClass wc;
WebDriver driver;
     
        @BeforeClass(alwaysRun = true)
        public void openBrowser() throws IOException{
        	BrowserFactory browserObj =new BrowserFactory(driver);
			driver=browserObj.startBrowser();
			wc = new WaitClass(driver);
		    wc.Wait(driver);    
		}
		
		@Test
		public void openHomePage() throws  MyNoSuchElementException, MyFileNotFoundException {
			HomePage homePage=new HomePage(driver);
			driver=homePage
		   .homePageCheckerObject(driver)
		   .homePageStatus(driver)
		   .loginButtonStatus(driver)
		   .clickLogin(driver);   
		}

		@Test(dependsOnMethods = { "openHomePage" })
		public void openLoginPage() throws  MyNoSuchElementException, MyNullPointerException, MyFileNotFoundException{
		    LoginPage login_page=new LoginPage(driver);
		    driver=login_page
		   .loginPageCheckerObject(driver)
		   .LoginPageStatus(driver)
		   .signupButtonStatus(driver)
		   .clicksignup(driver);
		    
		}
		
		@Test(dependsOnMethods = { "openLoginPage" })
		public void openSignUpPage() throws MyNoSuchElementException, MyNullPointerException, MyFileNotFoundException{
		    SignupPage signup_Page=new SignupPage(driver);
		    driver=signup_Page
		   .signupPageCheckerObject(driver)
		   .signupPageStatus(driver)
		   .signupTextBoxStatus(driver)
		   .signupID(driver)
		   .signupButtonStatus(driver)
		   .submitSignupId(driver);  
		}
		 @Test(dependsOnMethods = { "openSignUpPage" })
		 public void openMessage() throws MyNoSuchElementException, MyNullPointerException, MyIOException, MyFileNotFoundException{
			Message message=new Message(driver);
			driver = message
		   .waitVisibilityConditionByXpath(driver)
		   .WarningMessage(driver);
		 }
		 
		 @AfterClass(alwaysRun = true)
		 public void endTest(){
			wc.Wait(driver);
			driver.close(); 
		 }
}
