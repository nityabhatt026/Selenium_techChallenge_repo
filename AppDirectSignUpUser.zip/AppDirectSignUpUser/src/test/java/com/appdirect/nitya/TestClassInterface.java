package com.appdirect.nitya;

import java.io.IOException;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyIOException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.ExceptionHandling.MyNullPointerException;

public interface TestClassInterface {
	 public void openBrowser() throws IOException;
	 public void openHomePage() throws  MyNoSuchElementException, MyFileNotFoundException;
	 public void openLoginPage() throws  MyNoSuchElementException, MyNullPointerException, MyFileNotFoundException;
	 public void openSignUpPage() throws MyNoSuchElementException, MyNullPointerException, MyFileNotFoundException;
	 public void openMessage() throws MyNoSuchElementException, MyNullPointerException, MyIOException, MyFileNotFoundException;
	 public void endTest();
}
