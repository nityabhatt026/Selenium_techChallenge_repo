package com.ExceptionHandling;

public class MyNoSuchElementException extends Exception{
	
	    private static final long serialVersionUID = 1L;

	    public MyNoSuchElementException(String message) {
	       super(message);
	   }
	}

