package com.ExceptionHandling;

public class MyNullPointerException extends Exception{
	
	    private static final long serialVersionUID = 1L;

	    public MyNullPointerException(String message) {
	       super(message);
	   }
	}

