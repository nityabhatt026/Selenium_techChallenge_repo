package com.ExceptionHandling;

public class MyIOException extends Exception{

	    private static final long serialVersionUID = 1L;

	    public MyIOException(String message) {
	       super(message);
	   }
	}

