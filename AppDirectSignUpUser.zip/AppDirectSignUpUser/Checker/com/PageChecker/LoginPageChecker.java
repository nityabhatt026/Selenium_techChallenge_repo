package com.PageChecker;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.ExceptionHandling.MyNullPointerException;
import com.LoginPage.LoginPage;
import com.appdirect.nitya.utils.WaitClass;

import junit.framework.Assert;

public class LoginPageChecker {
	WebDriver driver;
	String signupPath;
	WaitClass wc=new WaitClass(driver);
	public LoginPageChecker(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		this.driver=driver;
		Properties prop = new Properties();
		try
		{
		InputStream input = new FileInputStream(new File("Pages/com/LoginPage/Login.properties"));
		prop.load(input);
		}
		catch(Exception e)
		{
			throw new MyFileNotFoundException("details of login not found");
		}
	    signupPath=prop.getProperty("signupPath");
	    if(signupPath==null){
		Reporter.log("signup element not found in exception handling in checker",true);
		throw new MyNoSuchElementException("signup element not found in exception handling in checker");
	}
	}
	
    public LoginPage signupButtonStatus(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		wc.waitVisibilityConditionByXpath(signupPath, driver);
		boolean buttonStatus=driver.findElement(By.xpath(signupPath)).isDisplayed();
		if(buttonStatus==true){
		Assert.assertTrue("SignUp Button Exist", buttonStatus);
		Reporter.log("SignUp Button Exist",true);
		}
		else{
		Assert.assertFalse("SignUp Button Doesn't Exist", buttonStatus);	
		Reporter.log("SignUp Button doesn't Exist",false);
		}
		return new LoginPage(driver);
	}

    public LoginPageChecker LoginPageStatus(WebDriver driver) throws MyNullPointerException, MyNoSuchElementException, MyFileNotFoundException{
	
	    String orignalTitle="Log In | AppDirect";
	    String title= driver.getTitle();
	    if(title==null){
		Reporter.log("login page title not found in checker in exception handling",true);
		throw new MyNullPointerException("login page title not found in checker in exception handling");
    	}
	    else{
		Assert.assertEquals(title, orignalTitle);
	    Reporter.log("Login Page Displayed",true);
	    }
        return new LoginPageChecker(driver);
}
}
