package com.PageChecker;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.ExceptionHandling.MyFileNotFoundException;
import com.ExceptionHandling.MyNoSuchElementException;
import com.SignUpPage.SignupPage;
import com.appdirect.nitya.utils.WaitClass;

import junit.framework.Assert;

public class SignupPageChecker {
	
	WebDriver driver;
	String signupTextboxPath;
	String signupButton;
	WaitClass wc=new WaitClass(driver);
	public SignupPageChecker(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		this.driver=driver;
		Properties prop = new Properties();
		try
		{
		InputStream input = new FileInputStream(new File("Pages/com/SignUpPage/SignUp.properties"));
		prop.load(input);
		}
		catch(Exception e)
		{
			throw new MyFileNotFoundException("detail of signup not found");
		}
		signupTextboxPath=prop.getProperty("signupTextboxPath");
		signupButton=prop.getProperty("signupButton");
		if(signupTextboxPath==null && signupButton==null){
			Reporter.log("signupTextboxPath or signupButton : No such element Exception in checker");
			throw new MyNoSuchElementException("signupTextboxPath or signupButton : No such element Exception in checker");
		}
	}
	public SignupPageChecker signupPageStatus(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
	    Assert.assertTrue(driver.getTitle().contains("Sign Up for AppDirect"));
	    Reporter.log("Verified the signup page",true);
	    return new SignupPageChecker(driver);
	}
	
    public SignupPage signupTextBoxStatus(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		
		boolean status=driver.findElement(By.cssSelector(signupTextboxPath)).isDisplayed();
		if(status==true){
		Assert.assertTrue("SignUp Text Box Exist", status);
		Reporter.log("SignUp Text Box Exist",true);
		}
		else{
		Assert.assertFalse("SignUp  Text Box Doesn't Exist", status);	
		Reporter.log("SignUp  Text Box doesn't Exist",false);
		}
		return new SignupPage(driver);
	}

	public SignupPage signupButtonStatus(WebDriver driver) throws MyNoSuchElementException, MyFileNotFoundException{
		boolean status=driver.findElement(By.cssSelector(signupButton)).isDisplayed();
		if(status==true){
		Assert.assertTrue("SignUp submit Button Exist", status);
		Reporter.log("SignUp submit Button Exist",true);
		}
		else{
		Assert.assertFalse("SignUp submit Button Doesn't Exist", status);	
		Reporter.log("SignUp submit Button doesn't Exist",false);
		}
		
		return new SignupPage(driver);
	}
}
