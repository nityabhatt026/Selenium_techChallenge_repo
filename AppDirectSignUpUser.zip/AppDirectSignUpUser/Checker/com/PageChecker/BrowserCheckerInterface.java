package com.PageChecker;

public interface BrowserCheckerInterface {
	public void browserCheck(String browser);
}
